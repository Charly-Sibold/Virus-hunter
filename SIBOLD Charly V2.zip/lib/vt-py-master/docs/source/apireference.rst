*************
API reference
*************

.. toctree::
   :maxdepth: 2

   Client <api/client>
   Feed <api/feed>
   Object <api/object>
   Iterator <api/iterator>
   Utilities <api/utils>
