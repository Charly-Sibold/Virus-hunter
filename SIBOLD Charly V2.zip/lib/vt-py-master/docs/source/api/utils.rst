*****************
Utility functions
*****************


.. automodule:: vt
    :members: url_id
    :noindex:
